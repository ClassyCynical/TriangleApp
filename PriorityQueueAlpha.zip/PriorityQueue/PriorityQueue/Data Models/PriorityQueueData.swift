//
//  PriorityQueueData.swift
//  PriorityQueue
//
//  Created by Christian Alexander Diaz on 3/11/23.
//  Copyright © 2023 Christian Alexander Diaz. All rights reserved.
//

import SwiftUI

var brotherStructList = [Brother]()

public func readBrotherDataFiles() {
    brotherStructList = decodeJsonFileIntoArrayOfStructs(fullFilename: "BrotherData.geojson", fileLocation: "Main Bundle")
}
