//
//  BrotherStruct.swift
//  PriorityQueue
//
//  Created by Christian Alexander Diaz on 3/11/23.
//  Copyright © 2023 Christian Alexander Diaz. All rights reserved.
//

import SwiftUI

struct Brother: Hashable, Codable, Identifiable {
    var id: Int
    var name: String
    var address: String
    var phone: String
    var priority: Int
}
