//
//  BrothersList.swift
//  PriorityQueue
//
//  Created by Christian Alexander Diaz on 3/11/23.
//  Copyright © 2023 Christian Alexander Diaz. All rights reserved.
//

import SwiftUI

struct BrothersList: View {
    var body: some View {
        NavigationView {
            List {
                // placeStructList is a global array of Place structs given in PlaceData.swift
                ForEach(brotherStructList) { aBrother in
                    NavigationLink(destination: BrotherDetails(brother: aBrother)) {
                        BrotherItem(brother: aBrother)
                    }
                }
            }
            .navigationBarTitle(Text("Brothers"), displayMode: .inline)
            
        }   // End of NavigationView
        .customNavigationViewStyle() // Given in NavigationStyle.swift
        
    }
}

struct BrothersList_Previews: PreviewProvider {
    static var previews: some View {
        BrothersList()
    }
}
