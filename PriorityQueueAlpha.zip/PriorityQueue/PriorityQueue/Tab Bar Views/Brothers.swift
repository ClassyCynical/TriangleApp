//
//  Brothers.swift
//  PriorityQueue
//
//  Created by Christian Alexander Diaz on 3/11/23.
//  Copyright © 2023 Christian Alexander Diaz. All rights reserved.
//

import SwiftUI

struct Brothers: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct Brothers_Previews: PreviewProvider {
    static var previews: some View {
        Brothers()
    }
}
