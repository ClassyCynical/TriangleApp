//
//  PriorityQueueBrotherDetails.swift
//  PriorityQueue
//
//  Created by Christian Alexander Diaz on 3/12/23.
//  Copyright © 2023 Christian Alexander Diaz. All rights reserved.
//

import SwiftUI
import MapKit

struct PriorityQueueBrotherDetails: View {
    let brother: Brother
    @State private var selectedMapTypeIndex = 0
    var mapTypes = ["Standard", "Satellite", "Hybrid", "Globe"]
    
    @State private var showAlertMessage = false
    @State private var alertTitle = ""
    @State private var alertMessage = ""
    
    @State private var addressCopied = false
    
    var body: some View {
        Form {
            Section(header: Text("Brother Name")) {
                Text(brother.name)
            }
//            Section(header: Text("Priority")) {
//                Text(String(brother.priority))
//            }
            
            Section(header: Text("Brother Address"), footer: Button(action: {
                        UIPasteboard.general.string = brother.address
                        addressCopied = true
                        showAlertMessage = true
                        alertTitle = "The Address Content Is Copied to Clipboard"
                        alertMessage = " "
                    }) {
                        Image(systemName: "doc.on.doc")
                            .font(.title)
                            .frame(maxWidth: .infinity, alignment: .center)
                    }) {
                        HStack {
                            Text(brother.address)
                            Spacer()
                            Button(action: {
                                let address = "\(brother.address)"
                                let geocoder = CLGeocoder()
                                geocoder.geocodeAddressString(address) { (placemarks, error) in
                                    guard let placemark = placemarks?.first, let location = placemark.location else {
                                        self.showAlertMessage = true
                                        self.alertTitle = "Error"
                                        self.alertMessage = "Could not find location"
                                        return
                                    }
                                    let mapItem = MKMapItem(placemark: MKPlacemark(coordinate: location.coordinate))
                                    mapItem.name = self.brother.name
                                    mapItem.openInMaps(launchOptions: nil)
                                }
                            }) {
                                Image(systemName: "mappin.and.ellipse")
                                    .font(.system(size: 24))
                                    .foregroundColor(.blue)
                            }
                        }
                    }
            Section(header: Text("Brother Phone Number")) {
                // Tap the phone number to display the Call phone number interface
                HStack {
                    Image(systemName: "phone")
                        .imageScale(.medium)
                        .font(Font.title.weight(.light))
                        .foregroundColor(Color.blue)
                    
                    //**************************************************************************
                    // This Link does not work on the Simulator since Phone app is not available
                    //**************************************************************************
                    Link(brother.phone, destination: URL(string: phoneNumberToCall(phoneNumber: brother.phone))!)
                }
                // Long press the phone number to display the context menu
                .contextMenu {
                    // Context Menu Item 1
                    //**************************************************************************
                    // This Link does not work on the Simulator since Phone app is not available
                    //**************************************************************************
                    Link(destination: URL(string: phoneNumberToCall(phoneNumber: brother.phone))!) {
                        Image(systemName: "phone")
                        Text("Call")
                    }
                    
                    // Context Menu Item 2
                    Button(action: {
                        // Copy the phone number to universal clipboard for pasting elsewhere
                        UIPasteboard.general.string = brother.phone
                        
                        showAlertMessage = true
                        alertTitle = "Phone Number is Copied to Clipboard"
                        alertMessage = "You can paste it on your iPhone, iPad, Mac laptop or Mac desktop each running under your Apple ID"
                    }) {
                        Image(systemName: "doc.on.doc")
                        Text("Copy Phone Number")
                    }
                }
            }
        }
        .alert(isPresented: $showAlertMessage) {
            Alert(title: Text(alertTitle), message: Text(alertMessage), dismissButton: .default(Text("OK")))
        }
    }
    
    func phoneNumberToCall(phoneNumber: String) -> String {
        // phoneNumber = (540) 231-4841
        
        let cleaned1 = phoneNumber.replacingOccurrences(of: " ", with: "")
        let cleaned2 = cleaned1.replacingOccurrences(of: "(", with: "")
        let cleaned3 = cleaned2.replacingOccurrences(of: ")", with: "")
        let cleanedNumber = cleaned3.replacingOccurrences(of: "-", with: "")
        
        // cleanedNumber = 5402314841
        
        return "tel:" + cleanedNumber
    }
}

struct PriorityQueueBrotherDetails_Previews: PreviewProvider {
    static var previews: some View {
        PriorityQueueBrotherDetails(brother: brotherStructList[0])
    }
}
