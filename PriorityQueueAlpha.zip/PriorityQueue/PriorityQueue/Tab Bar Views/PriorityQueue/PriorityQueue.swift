//  PriorityQueue.swift
//  PriorityQueue
//
//  Created by Christian Alexander Diaz on 3/12/23.
//  Copyright © 2023 Christian Alexander Diaz. All rights reserved.
//

import SwiftUI

struct PriorityQueue: View {
    @State private var queue: [Brother] = []
    @State private var showingAddBrotherView = false
    @State private var selectedBrother: Brother?
    
    var body: some View {
        NavigationView {
            VStack {
                if queue.isEmpty {
                    Text("The Priority Queue is Empty, click the + to add.")
                        .italic()
                } else {
                    List {
                        ForEach(queue) { brother in
                            Button(action: {
                                selectedBrother = brother
                            }) {
                                Text(brother.name)
                            }
                        }
                        .onDelete(perform: deleteBrothers)
                    }
                    .sheet(item: $selectedBrother) { brother in
                        PriorityQueueBrotherDetails(brother: brother)
                    }
                }
            }
            .navigationBarTitle("Priority Queue")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: {
                        showingAddBrotherView = true
                    }) {
                        Image(systemName: "plus")
                    }
                }
                
                ToolbarItem(placement: .navigationBarLeading) {
                    EditButton()
                }
            }
            .sheet(isPresented: $showingAddBrotherView) {
                AddBrotherView(brothers: brotherStructList, queue: $queue)
            }
        }
    }
    
    func deleteBrothers(at offsets: IndexSet) {
        queue.remove(atOffsets: offsets)
    }
}

struct AddBrotherView: View {
    let brothers: [Brother]
    @Binding var queue: [Brother]
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        NavigationView {
            List {
                ForEach(brothers) { brother in
                    Button(action: {
                        queue.append(brother)
                        presentationMode.wrappedValue.dismiss()
                    }) {
                        Text(brother.name)
                    }
                }
            }
            .navigationBarTitle(Text("Add a Person"))
        }
    }
}

struct PriorityQueue_Previews: PreviewProvider {
    static var previews: some View {
        PriorityQueue()
    }
}
