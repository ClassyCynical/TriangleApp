//
//  PriorityQueueBrotherItem.swift
//  PriorityQueue
//
//  Created by Christian Alexander Diaz on 3/12/23.
//  Copyright © 2023 Christian Alexander Diaz. All rights reserved.
//

import SwiftUI

struct PriorityQueueBrotherItem: View {
    
    // Input Parameter
    let brother: Brother
    
    var body: some View {
        HStack {
            VStack(alignment: .leading) {
                Text(brother.name)

                HStack {
                    Image(systemName: "phone")
                        .imageScale(.small)
                        .font(Font.title.weight(.thin))
                    Text(brother.phone)
                }
            }
            // Set font and size for the whole VStack content
            .font(.system(size: 14))
            
        }   // End of HStack
    }
}


struct PriorityQueueBrotherItem_Previews: PreviewProvider {
    static var previews: some View {
        PriorityQueueBrotherItem(brother: brotherStructList[0])
    }
}
