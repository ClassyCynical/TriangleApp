//
//  Settings.swift
//  PriorityQueue
//
//  Created by Christian Alexander Diaz on 3/11/23.
//  Copyright © 2023 Christian Alexander Diaz. All rights reserved.
//

import SwiftUI

/*
 A simple Settings page, but honestly, this only has the Dark Mode feature.
 */
struct Settings: View {
    @AppStorage("darkMode") private var darkMode = false
    
    var body: some View {
        Form {
            Section(header: Text("Dark Mode Setting"), footer: Text("because the light attracts the bugs...").italic()) {
                Toggle("Dark Mode", isOn: $darkMode)
            }
        }
        .navigationBarTitle(Text("Settings"), displayMode: .inline)
    }
}

struct Settings_Previews: PreviewProvider {
    static var previews: some View {
        Settings()
    }
}
