//
//  Home.swift
//  PriorityQueue
//
//  Created by Christian Alexander Diaz on 3/12/23.
//  Copyright © 2023 Christian Alexander Diaz. All rights reserved.
//

import SwiftUI

struct Home: View {
    var body: some View {
        Text("Priority Queue App")
    }
}

struct Home_Previews: PreviewProvider {
    static var previews: some View {
        Home()
    }
}
