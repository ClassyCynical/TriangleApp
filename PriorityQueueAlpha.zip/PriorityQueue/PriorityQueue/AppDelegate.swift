//
//  AppDelegate.swift
//  PriorityQueue
//
//  Created by Christian Alexander Diaz on 3/11/23.
//  Copyright © 2023 Christian Alexander Diaz. All rights reserved.
//

import SwiftUI
import UIKit


class AppDelegate: NSObject, UIApplicationDelegate {

    func application(_ application: UIApplication, didFinishLaunchingWithOptions
                     launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        readBrotherDataFiles()
        return true
    }

}

